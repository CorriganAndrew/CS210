#include "GroceryTracker.h"
#include <iostream>
#include <fstream>
#include <algorithm>

GroceryTracker::GroceryTracker(const std::string& inputFileName, const std::string& backupFileName)
    : inputFileName_(inputFileName), backupFileName_(backupFileName) {}

void GroceryTracker::LoadData() {
    ParseInputFile();
}

void GroceryTracker::ParseInputFile() {
    std::ifstream inFile(inputFileName_);
    if (!inFile.is_open()) {
        std::cerr << "Error: Could not open input file.\n";
        return;
    }

    std::string item;
    while (std::getline(inFile, item)) {
        if (!item.empty()) {
            // Optional: Trim or transform item to lowercase for consistency
            // std::transform(item.begin(), item.end(), item.begin(), ::tolower);
            itemFrequency_[item]++;
        }
    }
    inFile.close();
}

int GroceryTracker::GetFrequencyOfItem(const std::string& item) const {
    auto it = itemFrequency_.find(item);
    if (it != itemFrequency_.end()) {
        return it->second;
    } else {
        return 0;
    }
}

void GroceryTracker::PrintAllItems() const {
    for (const auto& pair : itemFrequency_) {
        std::cout << pair.first << " " << pair.second << "\n";
    }
}

void GroceryTracker::PrintHistogram() const {
    for (const auto& pair : itemFrequency_) {
        std::cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            std::cout << "*";
        }
        std::cout << "\n";
    }
}

void GroceryTracker::WriteBackupFile() const {
    std::ofstream outFile(backupFileName_);
    if (!outFile.is_open()) {
        std::cerr << "Error: Could not open backup file.\n";
        return;
    }

    for (const auto& pair : itemFrequency_) {
        outFile << pair.first << " " << pair.second << "\n";
    }
    outFile.close();
}
