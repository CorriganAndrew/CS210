#ifndef GROCERYTRACKER_H
#define GROCERYTRACKER_H

#include <string>
#include <map>

class GroceryTracker {
public:
    // Constructor
    GroceryTracker(const std::string& inputFileName, const std::string& backupFileName);

    // Load the data from the input file into the map
    void LoadData();

    // Return how many times a given item appears
    int GetFrequencyOfItem(const std::string& item) const;

    // Print each item and its frequency
    void PrintAllItems() const;

    // Print a histogram of item frequencies
    void PrintHistogram() const;

    // Write frequencies to backup file
    void WriteBackupFile() const;

private:
    std::string inputFileName_;
    std::string backupFileName_;
    std::map<std::string, int> itemFrequency_;

    // Helper function to parse the input file and fill the map
    void ParseInputFile();
};

#endif
