#include <iostream>
#include <limits>
#include "GroceryTracker.h"

int main() {
    // Create the tracker object
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");

    // Load data from input file into memory
    tracker.LoadData();

    // Create backup file
    tracker.WriteBackupFile();

    int choice = 0;
    while (choice != 4) {
        std::cout << "\nMenu:\n"
                  << "1. Search frequency of an item\n"
                  << "2. Print all items and frequencies\n"
                  << "3. Print histogram of items\n"
                  << "4. Exit\n"
                  << "Enter your choice: ";
        std::cin >> choice;

        // Validate input
        if (std::cin.fail()) {
            std::cin.clear(); // Clear error flags
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        switch (choice) {
            case 1: {
                std::cout << "Enter the item name: ";
                std::string userItem;
                std::cin >> userItem;
                int frequency = tracker.GetFrequencyOfItem(userItem);
                std::cout << userItem << " appears " << frequency << " times.\n";
                break;
            }
            case 2:
                tracker.PrintAllItems();
                break;
            case 3:
                tracker.PrintHistogram();
                break;
            case 4:
                std::cout << "Exiting the program.\n";
                break;
            default:
                std::cout << "Please select a valid option (1-4).\n";
        }
    }

    return 0;
}
